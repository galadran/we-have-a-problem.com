@echo off
setlocal ENABLEEXTENSIONS ENABLEDELAYEDEXPANSION

REM eMudhra Intermediate CA Compromise

REM This script adds the 16 compromised intermediate certs to the Untrusted
REM Certificates store.

REM https://emudhra.we-have-a-problem.com
REM https://github.com/galadran/we-have-a-problem.com


set PROBLEM=

for %%f in (EM*.crt) do (
  echo "%%f"
  certutil -addstore -f Disallowed "%%f"
  if !errorlevel! NEQ 0 set PROBLEM=1
  echo.
)

if defined PROBLEM (
  echo Error: Problem adding one or more certs to Untrusted Certificates.
) else (
  echo All certs added successfully to Untrusted Certificates.
)

