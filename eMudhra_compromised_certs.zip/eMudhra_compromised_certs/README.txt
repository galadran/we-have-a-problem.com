eMudhra Intermediate CA Compromise

This directory contains the 16 compromised intermediate certs.

Windows (Legacy): windows_legacy_block_certs.bat is a script that adds the 16
compromised intermediate certs to Untrusted Certificates.

https://emudhra.we-have-a-problem.com
https://github.com/galadran/we-have-a-problem.com
